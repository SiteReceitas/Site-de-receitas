document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('searchInput');
    const suggestions = document.createElement('div');
    suggestions.classList.add('suggestions');
    document.body.appendChild(suggestions);

    const recipes = [
        { title: 'Mojito', url: 'mojito.html' },
        { title: 'Pinã colada', url: 'pinacolada.html' },
        { title: 'Gin tônica', url: 'gin.html' },
        { title: 'Vinho quente', url: 'vinho.html' },
        { title: 'Negroni', url: 'negroni.html' }
        // Adicione mais receitas aqui
    ];

    searchInput.addEventListener('input', () => {
        const query = searchInput.value.toLowerCase();
        suggestions.innerHTML = '';
        
        if (query) {
            const filteredRecipes = recipes.filter(recipe => recipe.title.toLowerCase().includes(query));
            filteredRecipes.forEach(recipe => {
                const suggestion = document.createElement('div');
                suggestion.classList.add('suggestion');
                suggestion.textContent = recipe.title;
                suggestion.addEventListener('click', () => {
                    window.location.href = recipe.url;
                });
                suggestions.appendChild(suggestion);
            });
        }
    });
});
