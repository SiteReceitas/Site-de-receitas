let boxBuscar = document.querySelector('.buscarBox');
let lupa = document.querySelector('.lupabuscar');
let btnFechar = document.querySelector('.btn-fechar');
 
lupa.addEventListener('click', ()=> {
    boxBuscar.classList.add('ativar')
})
btnFechar.addEventListener('click', ()=> {
    boxBuscar.classList.remove('ativar')
    searchResults.innerHTML = '';
    searchInput.value = '';
});

searchInput.addEventListener('input', function() {
    const query = searchInput.value.toLowerCase();
    searchResults.innerHTML = '';
    
    if (query) {
        const results = files.filter(file => file.toLowerCase().includes(query));
        results.forEach(result => {
            const li = document.createElement('li');
            const a = document.createElement('a');
            a.href = result;
            a.textContent = result;
            li.appendChild(a);
            searchResults.appendChild(li);
        });
    }
});

document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('searchInput');
    const recipes = [
        { title: 'Mojito', url: 'mojito.html' },
        { title: 'Pinã colada', url: 'pinacolada.html' },
        { title: 'Gin tônica', url: 'gin.html' },
        { title: 'Negroni', url: 'negroni.html' },
        { title: 'Vinho quente', url: 'vinho.html' },
        { title: 'Guioza', url: 'guioza.html' },
        { title: 'Empadinha', url: 'empadinha.html' },
        { title: 'Torta de Frango', url: 'tortaf.html' },
        { title: 'Risoto', url: 'risoto.html' },
        { title: 'Muffin', url: 'muffin.html' },
        { title: 'Brigadeiro', url: 'brigadeiro.html' },
        { title: 'Pavê', url: 'pave.html' },
        { title: 'Cocada', url: 'cocada.html' },
        { title: 'Pudim', url: 'pudim.html' }
        // Adicione mais receitas aqui 
    ];

    searchInput.addEventListener('keypress', (event) => {
        if (event.key === 'Enter') {
            const query = searchInput.value.toLowerCase();
            const recipe = recipes.find(recipe => recipe.title.toLowerCase().includes(query));
            
            if (recipe) {
                window.location.href = recipe.url;
            } else {
                alert('Receita não encontrada!');
            }
        }
    });
});